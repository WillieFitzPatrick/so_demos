import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-generic-mat-button',
  templateUrl: './show-generic-mat-button.component.html',
  styleUrls: ['./show-generic-mat-button.component.css']
})
export class ShowGenericMatButtonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}